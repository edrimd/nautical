<template>
   <div class="fila">
      <!-- Detalles -->
      <div class="detalles sticky left-0">
         <div class="relative flex items-center justify-start">
            <input type="search" class="border-none shadow-none rounded-lg pl-10 w-full" placeholder="Filtrar" v-model="palabra" @keyup="filtrar(palabra)" />
            <iconos icono="buscar" class="w-4 absolute left-2" />
         </div>
      </div>
      <!-- Grid -->
      <div class="grid">
         <div
            v-for="(mes, index) in meses"
            :key="index"
            :style="{
               'grid-row-start': 1,
               'grid-column-start': mes.si,
               'grid-column-end': mes.sf,
            }"
            class="meses"
         >
            <h1>{{ mes.mes }}</h1>
         </div>
         <div
            v-for="(item, index) in 52"
            :key="index"
            :style="{
               'grid-row-start': 2,
               'grid-column-start': item,
               'grid-column-end': item + 1,
            }"
            class="fondo-cuadrito"
            :class="{ actual: item === result[1] }"
         >
            {{ item }}
         </div>
      </div>
   </div>
</template>

<script>
import Iconos from "@/components/Iconos.vue";
import { ref } from "@vue/reactivity";
import { useStore } from "vuex";

export default {
   components: { Iconos },
   props: {},

   setup() {
      const state = useStore().state;

      const meses = [
         { mes: "Enero", si: 1, sf: 5 },
         { mes: "Febrero", si: 5, sf: 9 },
         { mes: "Marzo", si: 9, sf: 14 },
         { mes: "Abril", si: 14, sf: 18 },
         { mes: "Mayo", si: 18, sf: 23 },
         { mes: "Junio", si: 23, sf: 27 },
         { mes: "Julio", si: 27, sf: 31 },
         { mes: "Agosto", si: 31, sf: 36 },
         { mes: "Septiembre", si: 36, sf: 40 },
         { mes: "Octubre", si: 40, sf: 44 },
         { mes: "Noviembre", si: 44, sf: 49 },
         { mes: "Diciembre", si: 49, sf: 53 },
      ];

      function getWeekNumber(d) {
         // Copy date so don't modify original
         d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
         // Set to nearest Thursday: current date + 4 - current day number
         // Make Sunday's day number 7
         d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
         // Get first day of year
         var yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
         // Calculate full weeks to nearest Thursday
         var weekNo = Math.ceil(((d - yearStart) / 86400000 + 1) / 7);
         // Return array of year and week number
         return [d.getUTCFullYear(), weekNo];
      }

      var result = getWeekNumber(new Date());

      const palabra = ref("");

      const filtrar = () => {
         const nuevoArray = state.arrayRegistros.filter((item) => {
            return item.nombre.toUpperCase().indexOf(palabra.value.toUpperCase()) > -1;
         });

         state.arrayRegistrosTemp = nuevoArray;
      };
      return { meses, result, palabra, filtrar };
   },
};
</script>

<style scoped>
.fila {
   display: flex;
   flex-direction: row;
   justify-content: flex-start;
   align-items: flex-start;
   width: 100%;
}

.fila:first-child .detalles {
   border-top-left-radius: 10px;
}
.fila:last-child .detalles {
   border-bottom-left-radius: 10px;
}
.detalles {
   background-color: white;
   padding-left: 10px;
   padding-right: 10px;
   flex: none;
   width: 250px;
   height: 50px;
   display: flex;
   flex-direction: row;
   justify-content: flex-start;
   align-items: center;
   z-index: 2;
   font-size: 13px;
}
.grid {
   display: grid;
   grid-template-columns: repeat(52, 40px);
   background-color: #f8f9fd;
   grid-template-rows: auto;
   grid-row-gap: 0px;
}

.fondo-cuadrito {
   z-index: 1;
   display: flex;
   justify-content: center;
   align-items: center;
   font-size: 10px;
   font-weight: 600;
   height: 1.4rem;
   background-color: #f8f9fd;
   color: #7e7e7e;
}

.meses {
   font-size: 0.8rem;
   text-align: center;
   padding-top: 0.3rem;
   padding-bottom: 0.3rem;
   color: #bfbfbf;
   /* border-color: #f0f0f0de;
   border-right-width: 2px; */
   background-color: #f4f5fa;
}
.meses:nth-child(2n + 1) {
   background-color: #f8f9fd;
}

.actual {
   background-color: #242b47;
   color: white;
   align-items: center;
   border-radius: 4px;
   width: 100%;
   height: 20px;
   margin-left: auto;
   margin-right: auto;
}
</style>

<template>
   <div>
      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'arrow-up'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 19V6M5 12l7-7 7 7" /></svg>
      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'arrow-down'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v13M5 12l7 7 7-7" /></svg>
      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'arrow-left'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H6M12 5l-7 7 7 7" /></svg>
      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'arrow-right'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h13M12 5l7 7-7 7" /></svg>
      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'arrow-up-left'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 17L7.8 7.7M7 17V7h10" /></svg>
      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'arrow-up-right'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M7 17l9.2-9.2M17 17V7H7" /></svg>
      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'arrow-down-left'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 7l-9.2 9.2M7 7v10h10" /></svg>
      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'menu'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
         <line x1="3" y1="12" x2="21" y2="12"></line>
         <line x1="3" y1="6" x2="21" y2="6"></line>
         <line x1="3" y1="18" x2="21" y2="18"></line>
      </svg>
      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'x'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
         <line x1="18" y1="6" x2="6" y2="18"></line>
         <line x1="6" y1="6" x2="18" y2="18"></line>
      </svg>
      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'chevron-right'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18l6-6-6-6" /></svg>
      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'grid'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
         <rect x="3" y="3" width="7" height="7"></rect>
         <rect x="14" y="3" width="7" height="7"></rect>
         <rect x="14" y="14" width="7" height="7"></rect>
         <rect x="3" y="14" width="7" height="7"></rect>
      </svg>
      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'plus'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
         <line x1="12" y1="5" x2="12" y2="19"></line>
         <line x1="5" y1="12" x2="19" y2="12"></line>
      </svg>
      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'calendar'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
         <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
         <line x1="16" y1="2" x2="16" y2="6"></line>
         <line x1="8" y1="2" x2="8" y2="6"></line>
         <line x1="3" y1="10" x2="21" y2="10"></line>
      </svg>
      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'check-square'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
         <polyline points="9 11 12 14 22 4"></polyline>
         <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>
      </svg>
      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'loader'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
         <line x1="12" y1="2" x2="12" y2="6"></line>
         <line x1="12" y1="18" x2="12" y2="22"></line>
         <line x1="4.93" y1="4.93" x2="7.76" y2="7.76"></line>
         <line x1="16.24" y1="16.24" x2="19.07" y2="19.07"></line>
         <line x1="2" y1="12" x2="6" y2="12"></line>
         <line x1="18" y1="12" x2="22" y2="12"></line>
         <line x1="4.93" y1="19.07" x2="7.76" y2="16.24"></line>
         <line x1="16.24" y1="7.76" x2="19.07" y2="4.93"></line>
      </svg>
      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'alert-triangle'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
         <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
         <line x1="12" y1="9" x2="12" y2="13"></line>
         <line x1="12" y1="17" x2="12.01" y2="17"></line>
      </svg>
      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'edit'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="16 3 21 8 8 21 3 21 3 16 16 3"></polygon></svg>
      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'check-circle'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
         <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
         <polyline points="22 4 12 14.01 9 11.01"></polyline>
      </svg>

      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'camera'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
         <g transform="translate(2 3)">
            <path d="M20 16a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V5c0-1.1.9-2 2-2h3l2-3h6l2 3h3a2 2 0 0 1 2 2v11z" />
            <circle cx="10" cy="10" r="4" />
         </g>
      </svg>

      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'message'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
         <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
      </svg>

      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'more-vertical'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
         <circle cx="12" cy="12" r="1"></circle>
         <circle cx="12" cy="5" r="1"></circle>
         <circle cx="12" cy="19" r="1"></circle>
      </svg>

      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'trash'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
         <polyline points="3 6 5 6 21 6"></polyline>
         <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
         <line x1="10" y1="11" x2="10" y2="17"></line>
         <line x1="14" y1="11" x2="14" y2="17"></line>
      </svg>
      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'square'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect></svg>
      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'chevron-down'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6" /></svg>
      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'chevron-up'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 15l-6-6-6 6" /></svg>

      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'map-marker'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
         <path d="M12 22s-8-4.5-8-11.8A8 8 0 0 1 12 2a8 8 0 0 1 8 8.2c0 7.3-8 11.8-8 11.8z" />
         <circle cx="12" cy="10" r="3" />
      </svg>

      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'send'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
         <path stroke="none" d="M0 0h24v24H0z" fill="none" />
         <line x1="10" y1="14" x2="21" y2="3" />
         <path d="M21 3l-6.5 18a0.55 .55 0 0 1 -1 0l-3.5 -7l-7 -3.5a0.55 .55 0 0 1 0 -1l18 -6.5" />
      </svg>

      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'mapa'" viewBox="0 0 24 24" stroke-width="1.2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
         <path stroke="none" d="M0 0h24v24H0z" fill="none" />
         <polyline points="3 7 9 4 15 7 21 4 21 17 15 20 9 17 3 20 3 7" />
         <line x1="9" y1="4" x2="9" y2="17" />
         <line x1="15" y1="7" x2="15" y2="20" />
      </svg>

      <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-mist" v-if="icono === 'diagrama'" viewBox="0 0 24 24" stroke-width="1.2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
         <path stroke="none" d="M0 0h24v24H0z" fill="none" />
         <path d="M5 5h3m4 0h9" />
         <path d="M3 10h11m4 0h1" />
         <path d="M5 15h5m4 0h7" />
         <path d="M3 20h9m4 0h3" />
      </svg>
      <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-message-circle-2" v-if="icono === 'chat'" viewBox="0 0 24 24" stroke-width="1.2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
         <path stroke="none" d="M0 0h24v24H0z" fill="none" />
         <path d="M3 20l1.3 -3.9a9 8 0 1 1 3.4 2.9l-4.7 1" />
         <line x1="12" y1="12" x2="12" y2="12.01" />
         <line x1="8" y1="12" x2="8" y2="12.01" />
         <line x1="16" y1="12" x2="16" y2="12.01" />
      </svg>
      <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-adjustments-horizontal" v-if="icono === 'ajustes'" viewBox="0 0 24 24" stroke-width="1.2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
         <path stroke="none" d="M0 0h24v24H0z" fill="none" />
         <circle cx="14" cy="6" r="2" />
         <line x1="4" y1="6" x2="12" y2="6" />
         <line x1="16" y1="6" x2="20" y2="6" />
         <circle cx="8" cy="12" r="2" />
         <line x1="4" y1="12" x2="6" y2="12" />
         <line x1="10" y1="12" x2="20" y2="12" />
         <circle cx="17" cy="18" r="2" />
         <line x1="4" y1="18" x2="15" y2="18" />
         <line x1="19" y1="18" x2="20" y2="18" />
      </svg>
      <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-search" v-if="icono === 'buscar'" viewBox="0 0 24 24" stroke-width="1.2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
         <path stroke="none" d="M0 0h24v24H0z" fill="none" />
         <circle cx="10" cy="10" r="7" />
         <line x1="21" y1="21" x2="15" y2="15" />
      </svg>

      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'save'" viewBox="0 0 24 24" stroke-width="1.2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
         <path stroke="none" d="M0 0h24v24H0z" fill="none" />
         <path d="M6 4h10l4 4v10a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2v-12a2 2 0 0 1 2 -2" />
         <circle cx="12" cy="14" r="2" />
         <polyline points="14 4 14 8 8 8 8 4" />
      </svg>

      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'plane1'" viewBox="0 0 24 24" stroke-width="1.2" stroke="none" fill="currentColor" stroke-linecap="round" stroke-linejoin="round">
         <path stroke="none" d="M0 0h24v24H0z" fill="none" />
         <path d="M16 10h4a2 2 0 0 1 0 4h-4l-4 7h-3l2 -7h-4l-2 2h-3l2 -4l-2 -4h3l2 2h4l-2 -7h3z" />
      </svg>

      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'plane2'" viewBox="0 0 24 24" stroke-width="1.2" stroke="none" fill="currentColor" stroke-linecap="round" stroke-linejoin="round">
         <path stroke="none" d="M0 0h24v24H0z" fill="none" />
         <path d="M15 12h5a2 2 0 0 1 0 4h-15l-3 -6h3l2 2h3l-2 -7h3z" transform="rotate(-15 12 12) translate(0 -1)" />
         <line x1="3" y1="21" x2="21" y2="21" />
      </svg>

      <svg xmlns="http://www.w3.org/2000/svg" v-if="icono === 'plane3'" viewBox="0 0 24 24" stroke-width="1.2" stroke="none" fill="currentColor" stroke-linecap="round" stroke-linejoin="round">
         <path stroke="none" d="M0 0h24v24H0z" fill="none" />
         <path d="M15 12h5a2 2 0 0 1 0 4h-15l-3 -6h3l2 2h3l-2 -7h3z" transform="rotate(15 12 12) translate(0 -1)" />
         <line x1="3" y1="21" x2="21" y2="21" />
      </svg>
   </div>
</template>
<script>
export default {
   props: {
      icono: {
         type: String,
         required: true,
      },
   },
   setup() {
      return {};
   },
};
</script>
<style scoped></style>

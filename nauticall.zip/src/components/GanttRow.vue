<template>
   <div class="fila">
      <!-- LISTA USUARIOS GANTT -->
      <div class="detalles sticky left-0">
         <div
            class="w-7 h-7 bg-black rounded-full mr-2 flex-none bg-cover bg-center"
            :style="{
               backgroundImage: `url(https://i.pravatar.cc/150?img=${Math.floor(Math.random() * (1 - 70)) + 70})`,
            }"
         ></div>
         <h1 class="truncate">{{ array.nombre }}</h1>
      </div>

      <!-- GANTT SEMANAS -->
      <div class="grid">
         <div
            v-for="(item, index) in 52"
            :key="index"
            :style="{
               'grid-row-start': 1,
               'grid-column-start': item,
               'grid-column-end': item + 1,
            }"
            class="fondo-cuadrito"
         />

         <div
            v-for="(item, index2) in array.itinerario"
            :key="index2"
            @click="
               verDetalles(item, index2, array);
               obtenerChats();
            "
            :style="{
               'grid-row-start': 1,
               'grid-column-start': parseInt(item.de, 0),
               'grid-column-end': parseInt(item.hasta, 0) + 1,
            }"
            :class="item.puerto.toLowerCase()"
            class="ficha"
         >
            {{ item.puerto }}
         </div>
      </div>
   </div>

   <teleport to="#modales">
      <div v-if="showDetails" class="ring p-10 w-full h-screen relative flex items-center justify-center">
         <div @click="showDetails = !showDetails" class="bg-black opacity-40 w-full h-full absolute z-20"></div>

         <!-- VENTANA PRINCIPAL DETALLES -->
         <div class="modal-detalles bg-white absolute p-4 z-40 rounded-lg flex flex-col items-center justify-start md:flex-row md:items-center md:justify-evenly">
            <!-- BOTÓN CERRAR -->
            <div @click="showDetails = !showDetails" class="absolute hover:bg-gray-200 md:bg-transparent bg-gray-600 text-white hover:text-gray-500 md:text-gray-500 top-5 md:top-2 md:right-2 w-8 h-8 rounded-full flex items-center justify-center cursor-pointer">
               <iconos icono="x" class="w-6"></iconos>
            </div>

            <!-- VISTA DETALLADA -->
            <div v-if="!editar" class="detalles-viaje overflow-y-auto sb relative">
               <div v-if="confirmacion" class="absolute w-full h-5/6 z-40 overflow-hidden rounded-lg flex items-center justify-center">
                  <div class="z-50 absolute">
                     <h1 class="text-white mb-4 font-semibold">¿Desea eliminar este registro?</h1>
                     <button class="p-3 bg-red-500 text-white rounded-lg mr-4" @click="eliminar()">Confirmar</button>
                     <button @click="confirmacion = !confirmacion" class="p-3 bg-gray-800 text-white rounded-lg">Cancelar</button>
                  </div>
                  <div class="bg-black opacity-50 w-80 h-44 rounded-xl absolute z-40"></div>
               </div>
               <!-- <h1 class="titulo w-full text-left">Detalles viaje</h1> -->
               <div class="bg-white p-4 flex items-center justify-between w-full rounded-lg border border-gray-200">
                  <div class="flex items-center justify-start">
                     <div
                        class="w-12 h-12 rounded-full bg-blue-400 mr-4 bg-cover bg-center shadow"
                        :style="{
                           backgroundImage: `url(https://i.pravatar.cc/150?img=${Math.floor(Math.random() * (1 - 70)) + 70})`,
                        }"
                     ></div>
                     <div class="flex flex-col w-auto items-start justify-between leading-none">
                        <h1 class="font-bold text-lg">{{ array.nombre }}</h1>
                        <h1 class="text-sm text-gray-500">{{ array.puesto }}</h1>
                     </div>
                  </div>
               </div>
               <div class="bg-white p-4 flex flex-col items-center justify-start w-full rounded-lg border border-gray-200 mt-2">
                  <h1 class="titulo text-left w-full">Salida</h1>
                  <div class="w-full flex items-center justify-around mb-4 border-b-2 border-dashed border-gray-200 pb-6">
                     <div class="flex flex-col items-start justify-center w-52">
                        <h1 class="text-gray-400">De:</h1>
                        <h1 class="text-base uppercase px-2 py-1 rounded-lg text-white barcelona">Barcelona</h1>
                        <h1 class="font-semibold">14/12/2021</h1>
                     </div>
                     <div class="bg-gray-200 text-black rounded-full w-10 h-10 flex items-center justify-center">
                        <iconos icono="plane2" class="w-6"></iconos>
                     </div>
                     <div class="flex flex-col items-end justify-center w-52">
                        <h1 class="text-gray-400">Hasta:</h1>
                        <h1 class="text-base uppercase px-2 py-1 rounded-lg text-white" :class="datosDetalles.puerto">
                           {{ datosDetalles.puerto }}
                        </h1>
                        <h1 class="font-semibold">14/12/2021</h1>
                     </div>
                  </div>
                  <h1 class="titulo text-left w-full">Regreso</h1>
                  <div class="w-full flex items-center justify-around mb-6">
                     <div class="flex flex-col items-start justify-center w-52">
                        <h1 class="text-gray-400">De:</h1>
                        <h1 class="text-base uppercase px-2 py-1 rounded-lg text-white" :class="datosDetalles.puerto">
                           {{ datosDetalles.puerto }}
                        </h1>
                        <h1 class="font-semibold">22/12/2021</h1>
                     </div>
                     <div class="bg-gray-200 text-black rounded-full w-10 h-10 flex items-center justify-center">
                        <iconos icono="plane3" class="w-6"></iconos>
                     </div>
                     <div class="flex flex-col items-end justify-center w-52">
                        <h1 class="text-gray-400">Hasta:</h1>
                        <h1 class="text-base uppercase px-2 py-1 rounded-lg text-white barcelona">Barcelona</h1>
                        <h1 class="font-semibold">22/12/2021</h1>
                     </div>
                  </div>
               </div>
               <div class="bg-white p-4 flex flex-col items-center justify-start w-full rounded-lg border border-gray-200 mt-2">
                  <h1 class="titulo w-full text-left">Observaciones</h1>
                  <p class="text-justify">
                     {{ datosDetalles.comentario }}
                  </p>
               </div>
               <div @click="showTicket = !showTicket" class="cursor-pointer bg-white p-4 flex flex-col items-center justify-start w-full rounded-lg border border-gray-200 mt-2">
                  <div class="flex items-center justify-center relative w-full">
                     <h1>Más detalles del vuelo</h1>
                     <iconos v-if="showTicket" icono="chevron-up" class="w-6 right-3 top-0 absolute"></iconos>
                     <iconos v-if="showTicket === false" icono="chevron-down" class="w-6 right-3 top-0 absolute"></iconos>
                  </div>
                  <img v-if="showTicket" alt="Vue logo" src="../assets/ticket.png" />
               </div>
               <div class="cursor-pointer p-4 flex flex-row items-center justify-center w-full mt-20">
                  <button @click="editar = !editar" class="boton rounded-l-lg">
                     <iconos icono="edit" class="w-5 mr-2" />
                  </button>
                  <button @click="confirmacion = !confirmacion" class="boton rounded-r-lg">
                     <iconos icono="trash" class="w-5 mr-2" />
                  </button>
               </div>
            </div>

            <!-- EDITAR -->
            <div v-if="editar" class="detalles-viaje overflow-y-auto sb">
               <div class="flex flex-col items-center justify-center">
                  <div class="w-full flex items-center justify-between mb-4">
                     <h1 class="text-xl font-bold">Editar Registro</h1>
                  </div>

                  <!-- RESPONSABLE -->
                  <div class="w-full flex flex-col items-center justify-start">
                     <h1 class="w-full text-left text-xs mb-1 font-semibold labell">Responsable</h1>

                     <select class="formulario" :value="datosDetalles.idUsuario">
                        <option v-for="(item, index) in arrayUsuarios" :key="index" :value="item.idUsuario">
                           {{ item.nombre }}
                        </option>
                     </select>

                     <!-- DESTINO -->
                     <h1 class="w-full text-left text-xs mb-1 font-semibold labell">Destino</h1>

                     <select class="formulario" :value="datosDetalles.idPuerto">
                        <option v-for="(item, index) in arrayPuertos" :key="index" :value="item.idPuerto">
                           {{ item.puerto }}
                        </option>
                     </select>

                     <div class="flex items-center justify-between w-full">
                        <div class="w-1/2 pr-2">
                           <h1 class="w-full text-left text-xs mb-1 font-semibold labell">Salida</h1>

                           <input class="formulario" type="week" :value="'2021-W' + (datosDetalles.de > 9 ? datosDetalles.de : '0' + datosDetalles.de)" />
                        </div>

                        <div class="w-1/2 pl-2">
                           <h1 class="w-full text-left text-xs mb-1 font-semibold labell">Regreso</h1>
                           <input class="formulario" type="week" :value="'2021-W' + (datosDetalles.hasta > 9 ? datosDetalles.hasta : '0' + datosDetalles.hasta)" />
                        </div>
                     </div>

                     <h1 class="w-full text-left text-xs mb-1 font-semibold labell">Observación / Comentario</h1>
                     <textarea class="formulario" cols="30" rows="2" :value="datosDetalles.comentario" />

                     <button class="hover:bg-blue-600 hover:shadow bg-blue-500 text-white w-full p-3 rounded-lg flex items-center justify-center">Guardar</button>
                     <button @click="editar = !editar" class="hover:bg-gray-600 hover:shadow bg-gray-500 text-white w-full p-3 mt-2 rounded-lg flex items-center justify-center">Cancelar</button>
                  </div>
               </div>
            </div>

            <!-- CHAT -->
            <div class="detalles-viaje bg-chat w-full overflow-y-auto sb">
               <div class="flex flex-col items-center justify-start w-full">
                  <h1 class="titulo">Histórico & Chat</h1>
                  <div :class="datosDetalles.puerto" class="w-full shadow-sm h-10 rounded-lg text-white flex items-center justify-center">
                     <h1>{{ datosDetalles.puerto }}</h1>
                  </div>
               </div>
               <div class="w-full chatchat flex flex-col items-center justify-start overflow-y-auto mt-6 pt-6 sb mb-1 px-2">
                  <div v-for="(item, index) in arrayChats" :key="index" class="w-full pb-2">
                     <mensajechat :array="item" />
                     <acontecimientochat :array="item" />
                  </div>
                  <div class="bg-white flex items-center justify-between w-full p-2 sticky bottom-0">
                     <input type="text" v-model="comentario" @keyup.enter="agregarComentario()" placeholder="Mensaje!" maxlength="120" />
                     <button @click="agregarComentario()" class="flex-none w-10 h-10 bg-blue-500 ml-4 rounded-full text-white flex items-center justify-center">
                        <iconos icono="send" class="w-5 h-5"></iconos>
                     </button>
                  </div>
               </div>
            </div>
            <!-- CHAT -->
         </div>
      </div>
   </teleport>
</template>

<script>
import { computed, ref } from "@vue/reactivity";
import Iconos from "./Iconos.vue";
import Acontecimientochat from "./Acontecimientochat.vue";
import Mensajechat from "./Mensajechat.vue";
import { useStore } from "vuex";

import formatISO9075 from "date-fns/formatISO9075";
import { onMounted } from "@vue/runtime-core";

export default {
   components: { Iconos, Acontecimientochat, Mensajechat },

   props: {
      index: { type: Number },
      array: { type: Object },
   },

   setup(props) {
      const state = useStore().state;

      const showDetails = ref(false);
      const showTicket = ref(false);
      const confirmacion = ref(false);
      const editar = ref(false);

      onMounted(() => {});

      const arrayUsuarios = computed(() => {
         return state.arrayUsuarios;
      });

      const arrayPuertos = computed(() => {
         return state.arrayPuertos;
      });

      const arrayChats = ref([]);

      const comentario = ref("");

      const datosDetalles = ref({
         idUsuario: 0,
         nombre: "",
         idPuerto: 0,
         puerto: "",
         comentario: "",
         de: 0,
         hasta: 0,
         index: -1,
      });

      const verDetalles = (item, index, array) => {
         datosDetalles.value.index = index;

         datosDetalles.value.nombre = array.nombre;
         datosDetalles.value.idUsuario = array.idUsuario;

         datosDetalles.value.idPuerto = item.idPuerto;
         datosDetalles.value.puerto = item.puerto;
         datosDetalles.value.comentario = item.comentario;
         datosDetalles.value.de = item.de;
         datosDetalles.value.hasta = item.hasta;

         showDetails.value = !showDetails.value;
      };

      const agregarComentario = () => {
         if (!comentario.value.length) return;

         if (state.arrayChats) {
            const index = state.arrayChats.findIndex((item) => {
               return item.idPuerto === datosDetalles.value.idPuerto;
            });

            // EXISTE PUERTO EN LA LISTA
            if (index === -1) {
               state.arrayChats.push({
                  idPuerto: datosDetalles.value.idPuerto,
                  puerto: datosDetalles.value.puerto,
                  chats: [
                     {
                        idUsuario: datosDetalles.value.idUsuario,
                        nombre: datosDetalles.value.nombre,
                        tipoChat: "MENSAJE",
                        contenido: comentario.value,
                        fechaCreado: formatISO9075(new Date()),
                     },
                  ],
               });
            }

            //NO EXISTE PUERTO EN LA LISTA
            if (index > -1) {
               state.arrayChats[index].chats.push({
                  idUsuario: datosDetalles.value.idUsuario,
                  nombre: datosDetalles.value.nombre,
                  tipoChat: "MENSAJE",
                  contenido: comentario.value,
                  fechaCreado: formatISO9075(new Date()),
               });
            }
         }

         obtenerChats();
         comentario.value = "";
      };

      const obtenerChats = () => {
         arrayChats.value = [];

         state.arrayChats.filter((item) => {
            if (item.idPuerto === datosDetalles.value.idPuerto) {
               item.chats.forEach((element) => {
                  arrayChats.value.push(element);
               });
            }
         });
      };

      const eliminar = () => {
         if (datosDetalles.value.index > -1) {
            props.array.itinerario[datosDetalles.value.index] = [];
            confirmacion.value = false;
            showDetails.value = false;
         }
      };

      return {
         showDetails,
         showTicket,
         editar,
         confirmacion,
         verDetalles,
         obtenerChats,
         arrayUsuarios,
         arrayPuertos,
         arrayChats,
         datosDetalles,
         comentario,
         agregarComentario,
         eliminar,
      };
   },
};
</script>

<style scoped>
.formulario {
   background-color: #f6f9fd;
   border-color: #e1e9f1;
   color: #33485f;
   padding: 0.8rem;
   margin-bottom: 1.3rem;
}

.formulario:focus {
   @apply ring-blue-500;
}

.labell {
   color: #a1adb9;
}

.ficha {
   z-index: 1;
   height: 30px;
   border-radius: 9999px;
   display: flex;
   justify-content: center;
   align-items: center;
   opacity: 90%;
   mix-blend-mode: multiply;
   color: white;
   font-size: 0.8rem;
   text-transform: uppercase;
   margin-top: auto;
   margin-bottom: auto;
   cursor: pointer;
}
.fila {
   display: flex;
   flex-direction: row;
   justify-content: flex-start;
   align-items: center;
   width: 100%;
}
.fila:hover .detalles {
   --tw-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
   box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
   background-color: #9b60fa;
   /* background-color: rgb(82, 143, 255); */
   color: white;
   z-index: 534;
   cursor: pointer;
}

.fila:first-child .detalles {
   border-top-left-radius: 10px;
}
.fila:last-child .detalles {
   border-bottom-left-radius: 10px;
}
.detalles {
   background-color: white;
   padding-left: 10px;
   padding-right: 10px;
   flex: none;
   width: 250px;
   height: 40px;
   display: flex;
   flex-direction: row;
   justify-content: flex-start;
   align-items: center;
   z-index: 2;
   font-size: 13px;
}
.grid {
   display: grid;
   grid-template-columns: repeat(52, 40px);
   background-color: #f8f9fd;
   grid-template-rows: 40px;
   grid-row-gap: 0px;
}

.vigo,
.VIGO {
   background-color: #ff9ff3;
}
.riveira,
.RIVEIRA {
   background-color: #feca57;
}
.bilbao,
.BILBAO {
   background-color: #ff6b6b;
}
.barcelona,
.BARCELONA {
   background-color: #48dbfb;
}
.madrid,
.MADRID {
   background-color: #1dd1a1;
}
.ecuador,
.ECUADOR {
   background-color: #00d2d3;
}
.panama,
.PANAMA {
   background-color: #54a0ff;
}
.costamarfil,
.COSTAMARFIL {
   background-color: #5f27cd;
}
.seychelles,
.SEYCHELLES {
   background-color: #cd7227;
}
.canarias,
.CANARIAS {
   background-color: #cd27b1;
}

.fondo-cuadrito {
   background-color: #f9fafe;
   z-index: 1;
   border-color: #eceff375;
   border-width: 1px;
}

.modal-detalles {
   width: 94%;
   padding: 1rem;
}

@media (min-width: 768px) {
   .modal-detalles {
      width: 80rem;
   }
}

.detalles-viaje {
   display: flex;
   flex-direction: column;
   align-items: center;
   justify-content: space-between;
   border-radius: 0.5rem;
   background-color: #f1f1f1;
   padding-right: 1rem;
   padding-left: 1rem;
   padding-top: 3rem;
}

@media (min-width: 768px) {
   .detalles-viaje {
      min-height: 70vh;
      max-height: 71vh;
      width: 35rem;
      padding-top: 1rem;
   }
}

.titulo {
   font-weight: 600;
   font-size: 0.9rem;
   text-transform: uppercase;
   color: #a1adb9;
   margin-bottom: 1rem;
}

.bg-chat {
   background-color: white;
}
.bg-chat .titulo {
   color: #292929;
   background-color: white;
}

.boton {
   padding: 0.5rem;
   width: 100px;
   background-color: #e2e2e2;
   display: flex;
   align-items: center;
   justify-content: center;
}
.boton:hover {
   background-color: #292929;
   color: whitesmoke;
}

.chatchat {
   max-height: 40vh;
}

@media (min-width: 768px) {
   .chatchat {
      max-height: 100vh;
   }
}
</style>

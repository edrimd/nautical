<template>
   <!-- ACONTECIMIENTO -->
   <div v-if="array.tipoChat === 'ACONTECIMIENTO'" class="w-full bg-blue-500 rounded-lg text-white mx-auto overflow-hidden mb-4">
      <h1 class="p-2">{{ array.contenido }}</h1>
      <div class="w-full bg-blue-600 flex items-center justify-start p-3">
         <div class="flex items-center justify-start w-1/2">
            <div
               class="w-7 h-7 bg-black rounded-full mr-2 flex-none bg-cover bg-center"
               :style="{
                  backgroundImage: `url(https://i.pravatar.cc/150?img=${Math.floor(Math.random() * (1 - 70)) + 70}` + ')',
               }"
            ></div>
            <h1 class="truncate uppercase">{{ array.nombre }}</h1>
         </div>
         <div class="w-1/2 bg-blue-600 text-xs flex items-center justify-between pt-1 pb-3 px-3">
            <div class="flex items-center justify-start py-2">
               <iconos icono="plane3" class="w-6 mr-3"></iconos>
               <h1>{{ array.fechaSalida }}</h1>
            </div>
            <div class="flex items-center justify-start py-2">
               <iconos icono="plane2" class="w-6 mr-3"></iconos>
               <h1>{{ array.fechaSalida }}</h1>
            </div>
         </div>
      </div>
   </div>
</template>
<script>
import Iconos from "./Iconos.vue";
export default {
   components: { Iconos },

   props: { array: { type: Object } },

   setup() {
      return {};
   },
};
</script>
<style></style>

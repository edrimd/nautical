<template>
   <button @click="abierto = !abierto" class="icono mr-5 bg-white flex-none hover:text-white w-10 h-10 rounded-lg hover:shadow flex items-center justify-center">
      <Iconos icono="menu" class="w-5"></Iconos>
   </button>
   <teleport to="#modales">
      <div v-if="abierto" @click="abierto = !abierto" class="w-full h-screen relative flex items-center justify-start">
         <div class="bg-black opacity-40 w-full h-full absolute z-20"></div>
         <div class="principal bg-white absolute p-4 z-40 left-4 rounded-lg flex flex-col items-center justify-around">
            <div @click="$router.push({ name: '/' })" class="flex items-center justify-start icono hover:text-blue-400 mb-8">
               <iconos icono="diagrama" class="w-10 fill-current" />
               <h1 class="texto hidden font-semibold ml-2">Gantt</h1>
            </div>
            <div @click="$router.push({ name: 'Mapa' })" class="flex items-center justify-start icono hover:text-blue-400 mb-8">
               <iconos icono="mapa" class="w-10 fill-current" />
               <h1 class="texto hidden font-semibold ml-2">Mapa</h1>
            </div>
            <div class="flex items-center justify-start icono hover:text-blue-400 mb-8">
               <iconos icono="chat" class="w-10 fill-current" />
               <h1 class="texto hidden font-semibold ml-2">Chats</h1>
            </div>
            <div class="flex items-center justify-start icono hover:text-blue-400">
               <iconos icono="ajustes" class="w-10 fill-current" />
               <h1 class="texto hidden font-semibold ml-2">Ajustes</h1>
            </div>
         </div>
      </div>
   </teleport>
</template>
<script>
import { ref } from "vue";
import Iconos from "@/components/Iconos.vue";
export default {
   components: { Iconos },
   props: {
      //   prop1: {
      //      type: String,
      //      required: false,
      //   },
   },
   setup() {
      const abierto = ref(false);
      return { abierto };
   },
};
</script>
<style scoped>
.icono {
   color: #7b7a93;
}

.icono:last-child {
   margin-bottom: 0px;
}
.icono:hover {
   cursor: pointer;
   color: #9b60fa;
}

.principal:hover .texto {
   display: inherit;
}
</style>

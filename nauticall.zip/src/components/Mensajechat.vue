<template>
   <!-- MENSAJE -->
   <div v-if="array.tipoChat === 'MENSAJE'" class="mensaje">
      <div class="w-5/6 rounded-lg overflow-hidden bg-mensaje p-3">
         <p class="w-full text-justify text-lg">{{ array.contenido }}</p>
         <div class="w-full xx flex items-center justify-between p-1">
            <div class="flex items-center justify-start yy">
               <div
                  class="w-7 h-7 bg-black rounded-full mr-2 flex-none bg-cover bg-center"
                  :style="{
                     backgroundImage: `url(https://i.pravatar.cc/150?img=${Math.floor(Math.random() * (70 - 1)) + 1})`,
                  }"
               ></div>
               <h1 class="truncate text-xs font-semibold mr-2">
                  {{ array.nombre }}
               </h1>
            </div>
            <h1 class="text-xs">{{ array.fechaCreado }}</h1>
         </div>
      </div>
   </div>
</template>

<script>
export default {
   props: { array: { type: Object } },

   setup() {
      return {};
   },
};
</script>

<style scoped>
.bg-mensaje {
   background-color: #e7e7e7;
}

.mensaje {
   display: flex;
   align-items: center;
   justify-content: start;
   margin-bottom: 12px;
}

.mensaje:nth-child(2n + 1) {
   justify-content: end;
}
.mensaje .xx {
   flex-direction: row;
}
.mensaje .xx .yy {
   flex-direction: row;
}
.mensaje:nth-child(2n + 1) .xx {
   flex-direction: row-reverse;
}
.mensaje:nth-child(2n + 1) .yy {
   flex-direction: row-reverse;
}

.mensaje:last-child {
   margin-bottom: 0px;
}
</style>

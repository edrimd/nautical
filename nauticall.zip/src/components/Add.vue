<template>
   <button @click="abierto = !abierto" class="icono mr-8 font-semibold bg-white px-3 h-10 flex-none rounded-lg hover:shadow text-xs flex items-center justify-center">
      <iconos icono="plus" class="w-5 mr-1" />
      <h1>Nuevo</h1>
   </button>

   <teleport to="#modales">
      <div v-if="abierto" class="w-full h-screen relative flex items-center md:justify-start justify-center">
         <div @click="abierto = !abierto" class="bg-black opacity-40 w-full h-full absolute z-20"></div>
         <div class="principal bg-white absolute p-4 z-40 md:left-4 rounded-lg flex flex-col items-center justify-start">
            <div class="w-full flex items-center justify-between mb-4">
               <h1 class="text-xl font-bold">Nuevo Registro</h1>
               <button @click="abierto = false" class="hover:bg-gray-100 rounded-full w-7 h-7 flex items-center justify-center self-end">
                  <iconos icono="x" class="w-5"></iconos>
               </button>
            </div>

            <!-- RESPONSABLE -->
            <div class="w-full flex flex-col items-center justify-start">
               <h1 class="w-full text-left text-xs mb-1 font-semibold labell">Responsable</h1>
               <select class="formulario" placeholder="Añadir" v-model="nuevo.idUsuario">
                  <option v-for="(item, index) in arrayUsuarios" :key="index" :value="item.idUsuario">
                     {{ item.nombre }}
                  </option>
               </select>

               <!-- DESTINO -->
               <h1 class="w-full text-left text-xs mb-1 font-semibold labell">Destino</h1>
               <select class="formulario" placeholder="Añadir" v-model="nuevo.idPuerto">
                  <option v-for="(item, index) in arrayPuertos" :key="index" :value="item.idPuerto">
                     {{ item.puerto }}
                  </option>
               </select>

               <div class="flex items-center justify-between w-full">
                  <div class="w-1/2 pr-2">
                     <h1 class="w-full text-left text-xs mb-1 font-semibold labell">Salida</h1>

                     <input class="formulario" type="week" v-model="nuevo.de" />
                  </div>
                  <div class="w-1/2 pl-2">
                     <h1 class="w-full text-left text-xs mb-1 font-semibold labell">Regreso</h1>
                     <input class="formulario" type="week" v-model="nuevo.hasta" />
                  </div>
               </div>

               <h1 class="w-full text-left text-xs mb-1 font-semibold labell">Observación / Comentario</h1>
               <textarea class="formulario" cols="30" rows="2" v-model="nuevo.comentario" />

               <button class="hover:bg-blue-600 hover:shadow bg-blue-500 text-white w-full p-3 rounded-lg flex items-center justify-center" @click="agregarNuevo()">Guardar</button>
            </div>
         </div>
      </div>
   </teleport>
</template>

<script>
import { computed, ref } from "vue";
import { useStore } from "vuex";
// import Iconos from "@/components/Iconos.vue";
import Iconos from "./Iconos.vue";
import formatISO9075 from "date-fns/formatISO9075";

export default {
   components: { Iconos },
   props: {},

   setup() {
      const state = useStore().state;
      const abierto = ref(false);

      const arrayUsuarios = computed(() => {
         return state.arrayUsuarios;
      });

      const arrayPuertos = computed(() => {
         return state.arrayPuertos;
      });

      const nuevo = ref({
         idUsuario: 0,
         idPuerto: 0,
         de: "",
         hasta: "",
         comentario: "",
      });

      const agregarNuevo = () => {
         if (nuevo.value.idUsuario <= 0 || nuevo.value.idPuerto <= 0 || nuevo.value.de == "" || nuevo.value.hasta == "") return;

         const puerto = state.arrayPuertos.filter((item) => {
            return item.idPuerto == nuevo.value.idPuerto;
         });

         const usuario = state.arrayUsuarios.filter((item) => {
            return item.idUsuario === nuevo.value.idUsuario;
         });

         if (state.arrayRegistros.length) {
            let contador = 0;

            state.arrayRegistros.forEach((item, index) => {
               // SI EXISTE EL USUARIO AGREGA ITINERARIO
               if (item.idUsuario === nuevo.value.idUsuario) {
                  console.log(1);
                  contador++;
                  state.arrayRegistros[index].itinerario.push({
                     idRegistro: Math.round(1, 1000000),
                     idPuerto: puerto[0].idPuerto,
                     puerto: puerto[0].puerto,
                     de: Math.abs(nuevo.value.de.replace("2021-W", "")),
                     hasta: Math.abs(nuevo.value.hasta.replace("2021-W", "")),
                     comentario: nuevo.value.comentario,
                  });
                  agregarComentario();
                  return;
               }
            });

            if (contador === 0) {
               // SINO EXISTE AGREGA ITINERARIO
               console.log(2);
               state.arrayRegistros.push({
                  ...usuario[0],
                  itinerario: [
                     {
                        idRegistro: Math.round(1, 1000000),
                        idPuerto: puerto[0].idPuerto,
                        puerto: puerto[0].puerto,
                        de: Math.abs(nuevo.value.de.replace("2021-W", "")),
                        hasta: Math.abs(nuevo.value.hasta.replace("2021-W", "")),
                        comentario: nuevo.value.comentario,
                     },
                  ],
               });
               agregarComentario();
            }
         }

         state.arrayRegistrosTemp = state.arrayRegistros;

         // LIMPIAR FORMULARIO
         nuevo.value.idUsuario = 0;
         nuevo.value.idPuerto = 0;
         nuevo.value.de = "";
         nuevo.value.hasta = "";
         nuevo.value.comentario = "";
         abierto.value = false;
      };

      const agregarComentario = () => {
         const puerto = state.arrayPuertos.filter((item) => {
            return item.idPuerto == nuevo.value.idPuerto;
         });

         const usuario = state.arrayUsuarios.filter((item) => {
            return item.idUsuario === nuevo.value.idUsuario;
         });

         if (state.arrayChats) {
            const index = state.arrayChats.findIndex((item) => {
               return item.idPuerto === nuevo.value.idPuerto;
            });

            // EXISTE PUERTO EN LA LISTA
            if (index === -1) {
               state.arrayChats.push({
                  idPuerto: puerto[0].idPuerto,
                  puerto: puerto[0].puerto,
                  chats: [
                     {
                        idUsuario: usuario[0].idUsuario,
                        nombre: usuario[0].nombre,
                        tipoChat: "ACONTECIMIENTO",
                        contenido: "!Nuevo viaje programado!",
                        fechaCreado: formatISO9075(new Date()),
                        fechaSalida: "2021-12-11",
                        fechaLlegada: "2021-12-11",
                     },
                  ],
               });
            }

            //NO EXISTE PUERTO EN LA LISTA
            if (index > -1) {
               state.arrayChats[index].chats.push({
                  idUsuario: usuario[0].idUsuario,
                  nombre: usuario[0].nombre,
                  tipoChat: "ACONTECIMIENTO",
                  contenido: "!Nuevo viaje programado!",
                  fechaCreado: formatISO9075(new Date()),
                  fechaSalida: "2021-12-11",
                  fechaLlegada: "2021-12-11",
               });
            }
         }
      };

      return {
         abierto,
         nuevo,
         state,
         arrayUsuarios,
         arrayPuertos,
         agregarNuevo,
      };
   },
};
</script>

<style scoped>
.icono {
   color: #7b7a93;
}

.icono:last-child {
   margin-bottom: 0px;
}
.icono:hover {
   cursor: pointer;
   color: #9b60fa;
}

.principal:hover .texto {
   display: inherit;
}

.principal {
   width: 90%;
}

@media (min-width: 768px) {
   .principal {
      width: 24rem;
   }
}

.formulario {
   background-color: #f6f9fd;
   border-color: #e1e9f1;
   color: #33485f;
   padding: 0.8rem;
   margin-bottom: 1.3rem;
}

.formulario:focus {
   @apply ring-blue-500;
}

.labell {
   color: #a1adb9;
}
</style>

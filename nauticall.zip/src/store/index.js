import { createStore } from 'vuex'

export default createStore(
  {

    state: {
      arrayUsuarios: [
        { idUsuario: 1, nombre: "PONCE DE LEON RODRIGUEZ", idPuesto: 1, puesto: "Tecnico" },
        { idUsuario: 2, nombre: "BERMEJO AZNAREZ", idPuesto: 1, puesto: "Tecnico" },
        { idUsuario: 3, nombre: "DE FRANCISCO GARCIA", idPuesto: 1, puesto: "Tecnico" },
        { idUsuario: 4, nombre: "DOMINGUEZ LEYENDA", idPuesto: 1, puesto: "Tecnico" },
        { idUsuario: 5, nombre: "FERNANDEZ ROBAINA", idPuesto: 1, puesto: "Tecnico" },
        { idUsuario: 6, nombre: "IZAGUIRRE", idPuesto: 1, puesto: "Tecnico" },
        { idUsuario: 7, nombre: "LOPEZ HERNANDEZ", idPuesto: 1, puesto: "Tecnico" },
        { idUsuario: 8, nombre: "MARTINEZ BARROS", idPuesto: 1, puesto: "Tecnico" },
        { idUsuario: 9, nombre: "MARTINEZ RODRIGUEZ", idPuesto: 1, puesto: "Tecnico" },
        { idUsuario: 11, nombre: "MENDEZ HERNANDEZ", idPuesto: 1, puesto: "Tecnico" },
        { idUsuario: 12, nombre: "PEREZ CARRILLO", idPuesto: 1, puesto: "Tecnico" },
        { idUsuario: 13, nombre: "QUEIRUGA SANLES", idPuesto: 1, puesto: "Tecnico" },
        { idUsuario: 14, nombre: "QUINTANA PEREZ", idPuesto: 1, puesto: "Tecnico" },
        { idUsuario: 15, nombre: "REAL SANTOS", idPuesto: 1, puesto: "Tecnico" },
        { idUsuario: 16, nombre: "RODRIGUEZ GONZALEZ", idPuesto: 1, puesto: "Tecnico" },
        { idUsuario: 17, nombre: "ROMERO ARBULU ARANZAZU", idPuesto: 1, puesto: "Tecnico" },
        { idUsuario: 18, nombre: "SANCHEZ MARTINEZ", idPuesto: 1, puesto: "Tecnico" },
        { idUsuario: 19, nombre: "SUAREZ CABRERA", idPuesto: 1, puesto: "Tecnico" },
        { idUsuario: 20, nombre: "UGALDE URIAGUERECA", idPuesto: 1, puesto: "Tecnico" },
        { idUsuario: 21, nombre: "VARELA SARTAL", idPuesto: 1, puesto: "Tecnico" },
        { idUsuario: 22, nombre: "VIDAL RAMOS", idPuesto: 1, puesto: "Tecnico" },
      ],

      arrayPuertos: [
        { idPuerto: 1, puerto: "VIGO" },
        { idPuerto: 2, puerto: "RIVEIRA" },
        { idPuerto: 3, puerto: "BILBAO" },
        { idPuerto: 4, puerto: "BARCELONA" },
        { idPuerto: 5, puerto: "MADRID" },
        { idPuerto: 6, puerto: "ECUADOR" },
        { idPuerto: 7, puerto: "PANAMA" },
        { idPuerto: 8, puerto: "COSTA MARFIL" },
        { idPuerto: 9, puerto: "SEYCHELLES" },
        { idPuerto: 10, puerto: "CANARIAS" },
      ],

      arrayRegistros: [
        {
          idUsuario: 1, nombre: "PONCE DE LEON RODRIGUEZ",
          itinerario: [
            {
              idPuerto: 2, puerto: "RIVEIRA",
              de: 10,
              hasta: 12,
              comentario: "Comentario x",
            },
            {
              idPuerto: 6, puerto: "ECUADOR",
              de: 13,
              hasta: 20,
              comentario: "Comentario x",
            },
            {
              idPuerto: 8, puerto: "COSTA MARFIL",
              de: 23,
              hasta: 30,
              comentario: "Comentario x",
            },
            {
              idPuerto: 3, puerto: "BILBAO",
              de: 30,
              hasta: 35,
              comentario: "Comentario x",
            },
            {
              idPuerto: 10, puerto: "CANARIAS",
              de: 38,
              hasta: 45,
              comentario: "Comentario x",
            },
            {
              idPuerto: 7, puerto: "PANAMÁ",
              de: 49,
              hasta: 52,
              comentario: "Comentario x",
            },
          ],
        },
        {
          idUsuario: 2, nombre: "BERMEJO AZNAREZ",
          itinerario: [
            {
              idPuerto: 2, puerto: "RIVEIRA",
              de: 1,
              hasta: 10,
              comentario: "Comentario x",
            },
            {
              idPuerto: 5, puerto: "MADRID",
              de: 12,
              hasta: 16,
              comentario: "Comentario x",
            },
            {
              idPuerto: 9, puerto: "SEYCHELLES",
              de: 20,
              hasta: 27,
              comentario: "Comentario x",
            },
            {
              idPuerto: 3, puerto: "BILBAO",
              de: 27,
              hasta: 37,
              comentario: "Comentario x",
            },
            {
              idPuerto: 7, puerto: "PANAMÁ",
              de: 37,
              hasta: 41,
              comentario: "Comentario x",
            },
            {
              idPuerto: 4, puerto: "BARCELONA",
              de: 46,
              hasta: 51,
              comentario: "Comentario x",
            },
          ],
        },
        {
          idUsuario: 3, nombre: "DE FRANCISCO GARCIA",
          itinerario: [
            {
              idPuerto: 3, puerto: "BILBAO",
              de: 3,
              hasta: 10,
              comentario: "Comentario x",
            },
            {
              idPuerto: 2, puerto: "RIVEIRA",
              de: 12,
              hasta: 16,
              comentario: "Comentario x",
            },
            {
              idPuerto: 4, puerto: "BARCELONA",
              de: 20,
              hasta: 27,
              comentario: "Comentario x",
            },
            {
              idPuerto: 5, puerto: "MADRID",
              de: 28,
              hasta: 37,
              comentario: "Comentario x",
            },
            {
              idPuerto: 7, puerto: "PANAMÁ",
              de: 37,
              hasta: 41,
              comentario: "Comentario x",
            },
            {
              idPuerto: 1, puerto: "VIGO",
              de: 46,
              hasta: 51,
              comentario: "Comentario x",
            },
          ],
        },
        {
          idUsuario: 4, nombre: "DOMINGUEZ LEYENDA",
          itinerario: [
            {
              idPuerto: 2, puerto: "RIVEIRA",
              de: 6,
              hasta: 9,

              comentario: "Comentario x",
            },
            {
              idPuerto: 6, puerto: "ECUADOR",
              de: 11,
              hasta: 15,
              comentario: "Comentario x",
            },
            {
              idPuerto: 9, puerto: "SEYCHELLES",
              de: 18,
              hasta: 25,
              comentario: "Comentario x",
            },
            {
              idPuerto: 8, puerto: "COSTA MARFIL",
              de: 29,
              hasta: 32,
              comentario: "Comentario x",
            },
            {
              idPuerto: 4, puerto: "BARCELONA",
              de: 45,
              hasta: 49,
              comentario: "Comentario x",
            },
            {
              idPuerto: 5, puerto: "MADRID",
              de: 49,
              hasta: 52,
              comentario: "Comentario x",
            },
          ],
        },
        {
          idUsuario: 5, nombre: "FERNANDEZ ROBAINA",
          itinerario: [
            {
              idPuerto: 2, puerto: "RIVEIRA",
              de: 2,
              hasta: 11,
              comentario: "Comentario x",
            },
            {
              idPuerto: 4, puerto: "BARCELONA",
              de: 11,
              hasta: 20,
              comentario: "Comentario x",
            },
            {
              idPuerto: 9, puerto: "SEYCHELLES",
              de: 22,
              hasta: 29,
              comentario: "Comentario x",
            },
            {
              idPuerto: 10, puerto: "CANARIAS",
              de: 34,
              hasta: 39,
              comentario: "Comentario x",
            },
            {
              idPuerto: 7, puerto: "PANAMÁ",
              de: 43,
              hasta: 45,
              comentario: "Comentario x",
            },
            {
              idPuerto: 8, puerto: "COSTA MARFIL",
              de: 48,
              hasta: 51,
              comentario: "Comentario x",
            },
          ],
        },
        {
          idUsuario: 6, nombre: "IZAGUIRRE",
          itinerario: [
            {
              idPuerto: 6, puerto: "ECUADOR",
              de: 4,
              hasta: 12,
              comentario: "Comentario x",
            },
            {
              idPuerto: 7, puerto: "PANAMÁ",
              de: 10,
              hasta: 15,
              comentario: "Comentario x",
            },
            {
              idPuerto: 9, puerto: "SEYCHELLES",
              de: 22,
              hasta: 29,
              comentario: "Comentario x",
            },
            {
              idPuerto: 8, puerto: "COSTA MARFIL",
              de: 28,
              hasta: 36,
              comentario: "Comentario x",
            },
          ],
        },
        {
          idUsuario: 7, nombre: "LOPEZ HERNANDEZ",
          itinerario: [
            {
              idPuerto: 1, puerto: "VIGO",
              de: 1,
              hasta: 2,

              comentario: "Comentario x",
            },
            {
              idPuerto: 6, puerto: "ECUADOR",
              de: 3,
              hasta: 13,
              comentario: "Comentario x",
            },
            {
              idPuerto: 9, puerto: "SEYCHELLES",
              de: 15,
              hasta: 24,
              comentario: "Comentario x",
            },
            {
              idPuerto: 8, puerto: "COSTA MARFIL",
              de: 31,
              hasta: 39,
              comentario: "Comentario x",
            },
            {
              idPuerto: 5, puerto: "MADRID",
              de: 39,
              hasta: 42,
              comentario: "Comentario x",
            },
            {
              idPuerto: 3, puerto: "BILBAO",
              de: 47,
              hasta: 52,
              comentario: "Comentario x",
            },
          ],
        },
      ],

      arrayRegistrosTemp: [
        {
          idUsuario: 1, nombre: "PONCE DE LEON RODRIGUEZ",
          itinerario: [
            {
              idPuerto: 2, puerto: "RIVEIRA",
              de: 10,
              hasta: 12,
              comentario: "Comentario x",
            },
            {
              idPuerto: 6, puerto: "ECUADOR",
              de: 13,
              hasta: 20,
              comentario: "Comentario x",
            },
            {
              idPuerto: 8, puerto: "COSTA MARFIL",
              de: 23,
              hasta: 30,
              comentario: "Comentario x",
            },
            {
              idPuerto: 3, puerto: "BILBAO",
              de: 30,
              hasta: 35,
              comentario: "Comentario x",
            },
            {
              idPuerto: 10, puerto: "CANARIAS",
              de: 38,
              hasta: 45,
              comentario: "Comentario x",
            },
            {
              idPuerto: 7, puerto: "PANAMÁ",
              de: 49,
              hasta: 52,
              comentario: "Comentario x",
            },
          ],
        },
        {
          idUsuario: 2, nombre: "BERMEJO AZNAREZ",
          itinerario: [
            {
              idPuerto: 2, puerto: "RIVEIRA",
              de: 1,
              hasta: 10,
              comentario: "Comentario x",
            },
            {
              idPuerto: 5, puerto: "MADRID",
              de: 12,
              hasta: 16,
              comentario: "Comentario x",
            },
            {
              idPuerto: 9, puerto: "SEYCHELLES",
              de: 20,
              hasta: 27,
              comentario: "Comentario x",
            },
            {
              idPuerto: 3, puerto: "BILBAO",
              de: 27,
              hasta: 37,
              comentario: "Comentario x",
            },
            {
              idPuerto: 7, puerto: "PANAMÁ",
              de: 37,
              hasta: 41,
              comentario: "Comentario x",
            },
            {
              idPuerto: 4, puerto: "BARCELONA",
              de: 46,
              hasta: 51,
              comentario: "Comentario x",
            },
          ],
        },
        {
          idUsuario: 3, nombre: "DE FRANCISCO GARCIA",
          itinerario: [
            {
              idPuerto: 3, puerto: "BILBAO",
              de: 3,
              hasta: 10,
              comentario: "Comentario x",
            },
            {
              idPuerto: 2, puerto: "RIVEIRA",
              de: 12,
              hasta: 16,
              comentario: "Comentario x",
            },
            {
              idPuerto: 4, puerto: "BARCELONA",
              de: 20,
              hasta: 27,
              comentario: "Comentario x",
            },
            {
              idPuerto: 5, puerto: "MADRID",
              de: 28,
              hasta: 37,
              comentario: "Comentario x",
            },
            {
              idPuerto: 7, puerto: "PANAMÁ",
              de: 37,
              hasta: 41,
              comentario: "Comentario x",
            },
            {
              idPuerto: 1, puerto: "VIGO",
              de: 46,
              hasta: 51,
              comentario: "Comentario x",
            },
          ],
        },
        {
          idUsuario: 4, nombre: "DOMINGUEZ LEYENDA",
          itinerario: [
            {
              idPuerto: 2, puerto: "RIVEIRA",
              de: 6,
              hasta: 9,

              comentario: "Comentario x",
            },
            {
              idPuerto: 6, puerto: "ECUADOR",
              de: 11,
              hasta: 15,
              comentario: "Comentario x",
            },
            {
              idPuerto: 9, puerto: "SEYCHELLES",
              de: 18,
              hasta: 25,
              comentario: "Comentario x",
            },
            {
              idPuerto: 8, puerto: "COSTA MARFIL",
              de: 29,
              hasta: 32,
              comentario: "Comentario x",
            },
            {
              idPuerto: 4, puerto: "BARCELONA",
              de: 45,
              hasta: 49,
              comentario: "Comentario x",
            },
            {
              idPuerto: 5, puerto: "MADRID",
              de: 49,
              hasta: 52,
              comentario: "Comentario x",
            },
          ],
        },
        {
          idUsuario: 5, nombre: "FERNANDEZ ROBAINA",
          itinerario: [
            {
              idPuerto: 2, puerto: "RIVEIRA",
              de: 2,
              hasta: 11,
              comentario: "Comentario x",
            },
            {
              idPuerto: 4, puerto: "BARCELONA",
              de: 11,
              hasta: 20,
              comentario: "Comentario x",
            },
            {
              idPuerto: 9, puerto: "SEYCHELLES",
              de: 22,
              hasta: 29,
              comentario: "Comentario x",
            },
            {
              idPuerto: 10, puerto: "CANARIAS",
              de: 34,
              hasta: 39,
              comentario: "Comentario x",
            },
            {
              idPuerto: 7, puerto: "PANAMÁ",
              de: 43,
              hasta: 45,
              comentario: "Comentario x",
            },
            {
              idPuerto: 8, puerto: "COSTA MARFIL",
              de: 48,
              hasta: 51,
              comentario: "Comentario x",
            },
          ],
        },
        {
          idUsuario: 6, nombre: "IZAGUIRRE",
          itinerario: [
            {
              idPuerto: 6, puerto: "ECUADOR",
              de: 4,
              hasta: 12,
              comentario: "Comentario x",
            },
            {
              idPuerto: 7, puerto: "PANAMÁ",
              de: 10,
              hasta: 15,
              comentario: "Comentario x",
            },
            {
              idPuerto: 9, puerto: "SEYCHELLES",
              de: 22,
              hasta: 29,
              comentario: "Comentario x",
            },
            {
              idPuerto: 8, puerto: "COSTA MARFIL",
              de: 28,
              hasta: 36,
              comentario: "Comentario x",
            },
          ],
        },
        {
          idUsuario: 7, nombre: "LOPEZ HERNANDEZ",
          itinerario: [
            {
              idPuerto: 1, puerto: "VIGO",
              de: 1,
              hasta: 2,

              comentario: "Comentario x",
            },
            {
              idPuerto: 6, puerto: "ECUADOR",
              de: 3,
              hasta: 13,
              comentario: "Comentario x",
            },
            {
              idPuerto: 9, puerto: "SEYCHELLES",
              de: 15,
              hasta: 24,
              comentario: "Comentario x",
            },
            {
              idPuerto: 8, puerto: "COSTA MARFIL",
              de: 31,
              hasta: 39,
              comentario: "Comentario x",
            },
            {
              idPuerto: 5, puerto: "MADRID",
              de: 39,
              hasta: 42,
              comentario: "Comentario x",
            },
            {
              idPuerto: 3, puerto: "BILBAO",
              de: 47,
              hasta: 52,
              comentario: "Comentario x",
            },
          ],
        },
      ],

      arrayChats: [{
        idPuerto: 1, puerto: "RIVEIRA", chats: [
          {
            idUsuario: 1,
            nombre: "PONCE DE LEON RODRIGUEZ",
            tipoChat: "ACONTECIMIENTO",
            contenido: "!Nuevo viaje programado!",
            fechaCreado: "2021-12-11",
            fechaSalida: "2021-12-11",
            fechaLlegada: "2021-12-11",

          },
          {
            idUsuario: 1,
            nombre: "PONCE DE LEON RODRIGUEZ",
            tipoChat: "ACONTECIMIENTO",
            contenido: "!Nuevo viaje programado!",
            fechaCreado: "2021-12-11",
            fechaSalida: "2021-12-11",
            fechaLlegada: "2021-12-11",

          }
        ]
      }]
    },

    mutations: {
    },

    actions: {
    },

    modules: {
    }
  }
);

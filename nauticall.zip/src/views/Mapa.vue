<template>
   <div class="principal">
      <div class="w-full h-16 sticky top-0 flex flex-row items-center justify-start">
         <Navegacion />
         <Add />
      </div>
      <div class="w-full h-full bg-gantt py-2 pr-2 overflow-auto flex items-center justify-center bg-pp">
         <img src="../assets/MAPA.svg" class="h-full" alt="" />
      </div>
   </div>
</template>

<script>
import Add from "@/components/Add.vue";
import Cabecera from "@/components/Cabecera.vue";
import GanttRow from "@/components/GanttRow.vue";
import Iconos from "@/components/Iconos.vue";
import Navegacion from "@/components/Navegacion.vue";
import { computed, ref } from "@vue/reactivity";
import { useStore } from "vuex";

export default {
   components: {
      Iconos,
      Navegacion,
      GanttRow,
      Add,
      Cabecera,
   },

   props: {},

   setup() {
      const state = useStore().state;

      const gant = computed(() => {
         return state.arrayRegistrosTemp;
      });

      return { gant, state };
   },
};
</script>

<style scoped>
.principal {
   padding: 20px;
   display: flex;
   flex-direction: column;
   justify-content: flex-start;
   align-items: center;
   width: 100%;
   height: 100vh;
}

.bg-gantt {
   background-color: #f8f9fd;
}

.bg-pp {
   background-color: white;
}
</style>

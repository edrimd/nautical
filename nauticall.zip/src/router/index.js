import { createRouter, createWebHashHistory } from 'vue-router'
import Start from '../views/Start.vue'
import Mapa from '../views/Mapa.vue'

const routes = [
  {
    path: '/',
    name: 'Start',
    component: Start
  },
  {
    path: '/mapa',
    name: 'Mapa',
    component: Mapa
  },
]

const router = createRouter({
  history: createWebHashHistory(process.env.BASE_URL),
  routes
})

export default router

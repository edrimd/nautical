<template>
   <!-- <div id="nav">
    <router-link to="/">Home</router-link> |
    <router-link to="/about">About</router-link>
  </div> -->
   <div id="modales" class="absolute w-full z-50"></div>
   <router-view />
</template>

<style>
#app {
   font-family: Avenir, Helvetica, Arial, sans-serif;
   -webkit-font-smoothing: antialiased;
   -moz-osx-font-smoothing: grayscale;
   text-align: center;
   color: #2c3e50;
}

#nav {
   padding: 30px;
}

#nav a {
   font-weight: bold;
   color: #2c3e50;
}

#nav a.router-link-exact-active {
   color: #42b983;
}

.sb::-webkit-scrollbar {
   width: 8px; /* width of the entire scrollbar */
}

.sb::-webkit-scrollbar-track {
   background: #f1f1f1; /* color of the tracking area */
}

.sb::-webkit-scrollbar-thumb {
   background-color: #5a5a5a; /* color of the scroll thumb */
   border-radius: 20px; /* roundness of the scroll thumb */
   border: 3px solid transparent; /* creates padding around scroll thumb */
}
</style>

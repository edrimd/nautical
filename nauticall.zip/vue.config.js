module.exports = {
  publicPath: './',
  assetsDir: './'
}